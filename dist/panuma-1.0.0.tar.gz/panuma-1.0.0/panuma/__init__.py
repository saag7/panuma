# panuma/__init__.py

import pandas as _pd
import numpy as _np
import matplotlib.pyplot as _plt

pd = _pd
np = _np
plt = _plt
